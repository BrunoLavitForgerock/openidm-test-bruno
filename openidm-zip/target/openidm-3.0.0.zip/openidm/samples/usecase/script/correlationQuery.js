
/*global source */

(function () {
	var map = {"_queryFilter": 'userName eq "' + source.userName + '"'};
    
    return map;
}());